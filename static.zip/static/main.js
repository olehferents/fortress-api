const app = new Vue({
  el: '#app',
  data: {
   title: 'Nestjs Websockets Chat',
   householdId: '5e89a239-54f0-4a49-9225-694110ab61a0',
  //  userId: '148bf485-dbb3-4a04-aa09-7120d832957d',
   body: 'SOCKETS, WORK PLEASE!!!',
   messages: [],
   households: [
     '8805ba6e-9a18-469f-90b4-df6d993c9c14',
     '8805ba6e-9a18-469f-90b4-df6d993'
   ],
   socket: null
  },
  methods: {
    firstHousehold() {
      this.socket ? this.socket.close() : null
      this.socket = io('http://localhost:8083')
      // this.householdId = this.households[0]
      this.socket.on(`msgToHouseholdClient${this.householdId}`, (message) => {
        console.log(message)
        this.receivedMessage(message)
       })
    },
    secondHousehold() {
      this.socket ? this.socket.close() : null
      this.socket = io('http://localhost:8083')
      // this.householdId = this.households[1]
      this.socket.on(`msgToHouseholdClient${this.householdId}`, (message) => {
        console.log(message)
        this.receivedMessage(message)
       })    },
   sendMessage() {
    // if(this.validateInput()) {
     const message = {
     householdId: this.householdId,
    //  userId: this.userId,
     body: this.body
    }
    this.socket.emit('msgToHousehold', message)
    this.body = ''
  //  }
  },
  receivedMessage(message) {
   this.messages.push(message)
  },
  // validateInput() {
  //  return this.householdId.length > 0 && this.body.length > 0 && this.userId.length > 0
  // }
 },
  // created() {
  //  this.socket = io('http://3.136.236.84')
  //  this.socket.on(`msgToClient${this.householdId}`, (message) => {
  //   console.log(message)
  //   this.receivedMessage(message)
  //  })
  // },
 })
